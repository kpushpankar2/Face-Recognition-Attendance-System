from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import webbrowser
import mysql.connector
import cv2


class Help:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1500x790+0+0")
        self.root.title("Face Recognition System")

        title_lbl = Label(self.root, text="HelpDesk", font=(
            "calibri", 35, "bold"), bg="white", fg="purple")
        title_lbl.place(x=0, y=0, width=1530, height=45)

        img_top = Image.open(r"College\helpdesk.png")
        img_top = img_top.resize((1530, 720), Image.ANTIALIAS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=55, width=1530, height=720)

        # Add Email button
        email_btn = Button(self.root, text="Email", font=("calibri", 20, "bold"), bg="white", fg="blue",
                           command=self.open_email)
        email_btn.place(x=600, y=350, width=120, height=40)

        # Add Contact button
        contact_btn = Button(self.root, text="Contact", font=("calibri", 20, "bold"), bg="white", fg="green",
                             command=self.open_contact)
        contact_btn.place(x=750, y=350, width=120, height=40)

    def open_email(self):
        webbrowser.open("mailto:kpushpankar2@gmail.com")

    def open_contact(self):
        messagebox.showinfo("Contact Information", "Contact: 9680968246")


if __name__ == "__main__":
    root = Tk()
    obj = Help(root)
    root.mainloop()
