from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import webbrowser
import mysql.connector
import cv2


class Developer:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1500x790+0+0")
        self.root.title("face Recognisation System")

        title_lbl = Label(self.root, text="DEVELOPER", font=(
            "calibri", 35, "bold"), bg="white", fg="purple")
        title_lbl.place(x=0, y=0, width=1530, height=45)

        img_top = Image.open(r"College\devel.jpg")
        img_top = img_top.resize((1530, 720), Image.ANTIALIAS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=55, width=1530, height=720)

        # Frame
        main_frame = Frame(f_lbl, bd=2)
        main_frame.place(x=1000, y=0, width=500, height=600)

        img_left = Image.open(r"College\pushpa.jpg")
        img_left = img_left.resize((200, 400), Image.ANTIALIAS)
        self.photoimg_left = ImageTk.PhotoImage(img_left)

        f_lbl = Label(main_frame, image=self.photoimg_left)
        f_lbl.place(x=300, y=0, width=200, height=400)

        # Developer Information
        dep_label = Label(main_frame,
                          text="Hello,My Name is Pushpankar Singh", font=("calibri", 14, "bold"), fg="purple", bg="white")
        dep_label.place(x=0, y=5)

        dep_label = Label(main_frame,
                          text="I am a full Stack Developer", font=("calibri", 14, "bold"), fg="purple", bg="white")
        dep_label.place(x=0, y=40)
        dep_label = Label(main_frame,
                          text="Email:kpushpankar2@gmail.com", font=("calibri", 14, "bold"), fg="purple", bg="white")
        dep_label.place(x=0, y=80)


if __name__ == "__main__":
    root = Tk()
    obj = Developer(root)
    root.mainloop()
